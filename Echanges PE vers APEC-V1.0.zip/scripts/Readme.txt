INTRODUCTION
============

Cette livraison contient les scripts suivants:
- un script encrypt.sh de chiffrement sym�trique AES-256 d'un fichier de donn�es � partir d'une cl� AES g�n�r�e � la vol�e et transmise dans un fichier chiffr�e RSA avec la partie publique de la cl� du partenaire.Les deux fichiers (fichier data et fichier des parametres AES) sont transmis dans une enveloppe tar.
 
- un script decrypt.sh de d�chiffrement du fichier issu du script pr�c�dent en appliquant les op�rations inverses.   

INSTALLATION
============
Apres avoir de-zipper le fichier , on obtient trois sous directories  : 

�	ENCRYPT
Usage :  ./encrypt/encrypt.sh <nom_du_fichier_�_chiffrer.csv>.
	Pas d'espace dans le nom du fichier en entr�e et extension csv
Contrainte : Pr�sence de la partie de la cle publique au format PEM sous ./encrypt/key. 
	Pr�sence fichier de configuration sous ./encrypt/encrypt.cfg
	
Fichier de sortie:  ./encrypt/out/echange-pe-apec-<timestamp>.tar 
	Fichier forma TAR contenant le fichier aes.parm(chiffr� RSA avec la cl� publique) et un fichier FichierAller.csv(chiffr� avec la cl� AES contenu dans le fichier pr�c�dent) dans le r�pertoire ./encrypt/out.
Fichier de log : Chaque passage produit un fichier  ./encrypt/log/log<timestamp>.txt

Le nom et la localisation des fichiers sont modifiables dans le fichier ./encrypt/encrypt.cfg.

�	DECRYPT
Usage :  ./decrypt/decrypt.sh <nom du fichier � d�crypt�> 
Contrainte : Presence de la cl� priv�e au format PEM sous ./decrypt/key.
	Pr�sence fichier de configuration sou ./encrypt/encrypt.cfg
Fichier de sortie : Le fichier data final est sous ./decrypt/out/FichierAller.csv 
Fichier de log : Chaque passage produit un fichier  ./decrypt/log/log<timestamp>.txt

Le nom et la localisation des fichiers sont modifiables dans le fichier ./decrypt/decrypt.cfg.

�	transfert
Contient un script test.sh permettant d'enchainer les deux scripts. 
On simule l'�mission d'un fichier csv en mettant un fichier csv dans depotChiffrement


NOTES TECHNIQUE
===============
	Ces scripts utilisent les commandes openSSL et tar.
	Les fichiers avant chiffrement n'ont pas �t� compress�s compte tenu de leur faible taille.
	Fichiers chiffres au format base64 sans compression openSSL.
	Un lien symbolique sur les derniers logs est disponible