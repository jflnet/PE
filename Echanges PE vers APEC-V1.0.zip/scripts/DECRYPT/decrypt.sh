#!/bin/bash
############################################################################################
#Script de dechiffrement du fichier transmis par Pôle Emploi
#Version
#   1.0 : creation (JFL)
############################################################################################
#-- Initialisation
 TMS=$(date +"%d%m%Y-%T")
 logfile=./log/log${TMS}.txt
 conffile=./decrypt.cfg
#-- initialisation des directories
 [ -d out ] || mkdir out
 [ -d log ] || mkdir log
 [ -d tmp ] || mkdir tmp
#-- Initialisation
echo $(date +"%d%m%Y-%T") "INFO - Debut traitement du dechiffrement du fichier "  >$logfile
 ln -f $logfile ./log/lastlog.txt

#-- Chargement fichier de conf
 if [ -e $conffile ];then
    echo ${TMS} "INFO - Chargement du fichier de config" $conffile >>$logfile
	source $conffile
 else
     echo  ${TMS} "ERREUR - "  " Le fichier à chiffrer en entrée"  $filetoencrypt " n'existe pas" >>$logfile
     exit 8
 fi
#-- Recuperation des parametres d'entree 
 if [ $# -ne 1 ]; then
    echo $(date +"%d%m%Y-%T") "ERREUR - "  " Le script doit etre invoque avec un premier argument donnant le fichier à dechiffrer " >>$logfile
    exit 8
fi
filetodecrypt=$1
if [ ! -e $filetodecrypt ]; then
	echo  $(date +"%d%m%Y-%T") "ERREUR - "  " Le fichier à chiffrer en entrée"  $filetodecrypt " n'existe pas" >>$logfile
    exit 8 
fi
#-- Fichiers temporaires de travail 
 parametersAESfiletodecrypt=./tmp/aes.parm
 decryptedparametersAESfile=./tmp/aes.parm.dec
 
#-- untar du fichier 
 tar -xf $filetodecrypt -C ./tmp   
 STATUS="$?"
 if [ ${STATUS} -ne 0 ];then
    echo $(date +"%d%m%Y-%T") "ERREUR - UNTAR du fichier"  $filetodecrypt >>$logfile  
    exit 8
 else  
    echo $(date +"%d%m%Y-%T") "INFO - Traitement OK de untar du fichier" $filetodecrypt >>$logfile 
 fi
 datafile=$(ls -t ./tmp/*.csv | head -1)
 datafiletodecrypt=./tmp/$(basename ${datafile})
 decrypteddatafile=./out/$(basename ${datafile})
 
#-- Dechiffrer le fichier parametres AES
 openssl rsautl -decrypt -in $parametersAESfiletodecrypt -inkey $keypairfile  -out $decryptedparametersAESfile &>>$logfile
 STATUS="$?"
 if [ ${STATUS} -ne 0 ];then
    echo $(date +"%d%m%Y-%T") "ERREUR - Erreur sur dechiffrement RSA du fichier des parametres AES" >>$logfile  
    exit 8
 else  
    echo $(date +"%d%m%Y-%T") "INFO - Traitement OK de dechiffrement du fichier des parametres AES" >>$logfile 
 fi

 AESkey=$(grep -Po "(?<=^key=).*" $decryptedparametersAESfile)
 AESiv=$(grep -Po "(?<=^iv =).*"  $decryptedparametersAESfile)

#-- Dechiffrement AES du fichier data
tempfile1=./tmp/tempfile1
tempfile2=./tmp/tempfile2
mv $datafiletodecrypt $tempfile1
 openssl enc  -d  $optionsAES -$algoSymetric -in $tempfile1 -out $tempfile2  -K $AESkey -iv $AESiv &>>$logfile
 STATUS="$?"
 if [ ${STATUS} -ne 0 ];then
    echo $(date +"%d%m%Y-%T") "ERREUR - Erreur sur dechiffrement AES du fichier data" >>$logfile  
    exit 8
 else  
    echo $(date +"%d%m%Y-%T") "INFO - Traitement OK de dechiffrement AES du fichier de data" >>$logfile 
 fi
 mv $tempfile2 $decrypteddatafile
#-- Suppresion des fichiers de travail
rm -f  ./tmp/*
echo $(date +"%d%m%Y-%T") "INFO - Fin traitement du dechiffrement du fichier "  >>$logfile
