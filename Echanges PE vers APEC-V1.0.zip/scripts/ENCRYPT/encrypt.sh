#!/bin/bash

############################################################################################
#Script de chiffrement du fichier Pôle Emploi
###Version
#   1.0 : creation (JFL)
######################################################################################################################################################################################
#-- Initialisation
 TMS=$(date +"%d%m%Y-%T")
 logfile=./log/log${TMS}.txt
#-- initialisation des directories
 [ -d out ] || mkdir out
 [ -d log ] || mkdir log
 [ -d tmp ] || mkdir tmp
#-- Initialisation
 conffile=./encrypt.cfg
 
 echo $TMS "INFO - Debut traitement du chiffrement du fichier à destination APEC"  >$logfile
 ln -f $logfile ./log/lastlog.txt
#-- Chargement fichier de conf
 if [ -e $conffile ];then
    echo $(date +"%d%m%Y-%T") "INFO - Chargement du fichier de config" $conffile >>$logfile
	source $conffile
 else
     echo  $(date +"%d%m%Y-%T") "ERREUR - "  " Le fichier à chiffrer en entrée"  $filetoencrypt " n'existe pas" >>$logfile
     exit 8
 fi
   
   echo $(date +"%d%m%Y-%T") "INFO - Reference traitement :" ${TMS}  >>$logfile

#-- Recuperation des parametres
if [ $# -ne 1 ]; then
    echo $(date +"%d%m%Y-%T") "ERREUR - "  " Le script doit etre invoque avec un premier argument donnant le fichier à chiffrer " >>$logfile
    exit 8
fi
filetoencrypt=$1
if [ ! -e $filetoencrypt ]; then
	echo  $(date +"%d%m%Y-%T") "ERREUR - "  " Le fichier à chiffrer en entrée"  $filetoencrypt " n'existe pas" >>$logfile
    exit 8 
fi


#-- Controles existence des  fichiers  d'entree
 if [ ! -e $filetoencrypt ]; then
    echo  $(date +"%d%m%Y-%T") "ERREUR - "  " Le fichier à chiffrer "  $filetoencrypt " n'existe pas" >>$logfile
    exit 8 
 fi
 if [ ! -e $publicKeyfile ]; then
    echo  $(date +"%d%m%Y-%T") "ERREUR - "  " Le fichier contenant la clé publique "  $filetoencrypt " est absent" >>$logile
    exit 8 
 fi
#-- Fichiers internes au script 
 
 encrypteddatafile=./tmp/$(basename ${filetoencrypt})
 encryptedparmAESfile=./tmp/$nameencryptedparmAESfile
 parmAESfile=./tmp/$nameencryptedparmAESfile.enc
 
#--Generer la cle AES + vecteur initialisation
 alea=$(openssl rand -hex 32)
 openssl enc  -$algoSymetric -k $alea -P -iter +2 -nosalt >  $parmAESfile  
 STATUS="$?"
 if [ ${STATUS} -ne 0 ];then
    echo $(date +"%d%m%Y-%T") "ERREUR - Erreur de la génération de la clé AES"  >>$logfile  
    exit 8
 else
    echo $(date +"%d%m%Y-%T") "INFO - Traitement OK de generation de la cle AES"  >>$logfile 
 fi
 AESkey=$(grep -Po "(?<=^key=).*" $parmAESfile)
 AESiv=$(grep -Po "(?<=^iv =).*"  $parmAESfile)
 echo $(date +"%d%m%Y-%T") "INFO - Generation cle AES key:" $AESkey " iv: " $AESiv  >>$logfile 
#--Chiffrement asymetrique RSA du fichier de données avec la clé pubique du partenaire
 openssl rsautl -encrypt  -in $parmAESfile -inkey $publicKeyfile -out $encryptedparmAESfile -pubin  &>>$logfile
 STATUS="$?"
 if [ ${STATUS} -ne 0 ];then
    echo $(date +"%d%m%Y-%T") "ERREUR - Erreur lors du chiffrement asymetrique openSSL rsault du fichier parametres AES"  1>>$logfile  
    exit 8
 else
    echo $(date +"%d%m%Y-%T") "INFO - Traitement OK de chiffrement asymetrique RSA du fichier parametres AES"   1>>$logfile 
 fi
 
#--Chiffrement symetrique du fichier de données
 openssl enc  -$algoSymetric  $optionsAES -in $filetoencrypt -out $encrypteddatafile  -K $AESkey -iv $AESiv &>>$logfile
 STATUS="$?"
 if [ ${STATUS} -ne 0 ];then
    echo $(date +"%d%m%Y-%T") "ERREUR - Erreur lors du chiffrement symetrique AES du fichier de données"  1>>$logfile  
    exit 8
 else
    echo $(date +"%d%m%Y-%T") "INFO - Traitement OK de chiffrement symetrique AES du fichier de donnees"  1>>$logfile 
 fi
#horodatage du fichier de data
 fichierHorodate=./tmp/$(basename ${filetoencrypt} .csv)"-"${TMS}".csv"
 mv $encrypteddatafile $fichierHorodate
#-- tar des deux fichiers     
 
 tar -cf ${TARfile}  --directory ./tmp $(basename ${encryptedparmAESfile}) $(basename ${fichierHorodate}) &>>$logfile
  
 STATUS="$?"
 if [ ${STATUS} -ne 0 ];then
    echo $(date +"%d%m%Y-%T") "ERREUR - TAR des fichiers"  $TARfile >>$logfile  
    exit 8
 else  
    echo $(date +"%d%m%Y-%T") "INFO - Traitement OK de generation du TAR  des deux fichiers data + parametres AES" $Tarfile 1>>$logfile 
 fi
#### IMPORTANT A SUPPRIMER EN PROD

 rm -f  ./tmp/*
 echo $(date +"%d%m%Y-%T") "INFO - Fin de script" >>$logfile
