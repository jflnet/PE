#!/bin/bash
 echo "--" $(date +"%d%m%Y-%T") "------CHIFFREMENT----------------------------------"
 cd ../ENCRYPT
#--Recuperer le fichier a chiffrer le plus recent 
 toEncrypt=$(ls -t ../transfert/depotChiffrement/*.csv | head -1)
 echo "Fichier à chiffer " $toEncrypt
 ./encrypt.sh $toEncrypt
#- Test OK ou KO
 if [ $? -ne 0 ]; then 
	echo "Chiffrement KO"
	exit
 else
	echo "chiffrement OK."
 fi
#--simuler le transfert
echo "--" $(date +"%d%m%Y-%T") "------TRANSFERT--------------------------------------"
 filetransfert=$(ls -t ./out/*.tar | head -1)
 cp $filetransfert ../transfert/DepotDechiffrement/
 echo "Fichier transfere sur depotDechiffrement " $filetransfert
 echo "--" $(date +"%d%m%Y-%T") "------DECHIFFREMENT---------------------------------"
#- recupére le fichier le sortie du chiffrement pour le mettre en entrée du dechiffrement
 filetodecrypt=$(ls -t ../transfert/depotDechiffrement/*tar | head -1)
 echo "Fichier a dechiffrer " $filetodecrypt
#- lance le dechiffrement
 cd ../DECRYPT
 ./decrypt.sh $filetodecrypt
 #- Test OK ou KO
if [ $? -ne 0 ]; then 
	echo "Dechiffrement KO"
	exit
else
	echo "Dechiffrement OK."
fi
Decrypted=$(ls -t ../DECRYPT/out/*csv | head -1)
echo "Fichier dechiffre " $Decrypted
# Comparaison
toDecrypt=$(ls -t ../transfert/depotChiffrement/*csv | head -1)
echo "--" $(date +"%d%m%Y-%T") "------COMPARAISON----------------------------------"
echo "Comparaison "  $toDecrypt "et "$Decrypted
diff $toDecrypt $Decrypted
if [ $? -ne 0 ]; then 
	echo "Comparaison KO"
	exit
else
	echo "Comparaison OK."
fi	