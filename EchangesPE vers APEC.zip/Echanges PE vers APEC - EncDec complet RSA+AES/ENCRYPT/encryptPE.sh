#!/bin/bash
parmfile=./out/aes.parm
filetoencrypt=./in/FichierAller.csv
encryptedfile=./out/FichierAller.csv
TARfile=./out/echange-pe-apec-10122021.tgz

#-- Initialisation
TMS=$(date +"%d%m%Y-%T")
algoSymetric="aes-256-cbc"
logfile=./log/log${TMS}.txt


#-- 
echo  ${TMS} "INFO - Traitement chiffrement fichier à destinnation APEC " 1>>$logfile   
rm -f  ./out/*
rm -f  ./log/*
rm -f  ./tmp/*
#-- Fichier de conf
#if [ -z "$1" ];then
#    source config.txt
#else
#    source $1
#fi
#--
#-- Controles
if [ ! -e $filetoencrypt ]; then
    logstr= ${TMS} "ERREUR - "  " Le fichier à chiffrer "  $filetoencrypt " n'existe pas"
    exit 8 
fi
if [ ! -d "./tmp" ]; then
    mkdir ./tmp
fi

#--Generer la cle AES + vecteur initialisation
 alea=$(openssl rand -hex 32)
 openssl enc  -$algoSymetric -k $alea -P -iter +2 -nosalt >  ./tmp/parmAES  
 STATUS="$?"
 if [ ${STATUS} -ne 0 ];then
    echo $(date +"%d%m%Y-%T") "ERREUR - Erreur lors du chiffrement symetrique openSSL enc"  1>>$logfile  
    exit 8
 else
    echo $(date +"%d%m%Y-%T") "INFO - Debut traitement du chiffrement du fichier à destinnation APEC"  1>>$logfile 
 fi
 AESkey=$(grep -Po "(?<=^key=).*" ./tmp/parmAES)
 AESiv=$(grep -Po "(?<=^iv =).*" ./tmp/parmAES)
 echo $(date +"%d%m%Y-%T") "INFO - Generation cle AES key:" $AESkey " iv: " $AESiv  1>>$logfile 

 
#--Chiffrement asymetrique RSA du fichier de données avec la clé pubique du partenaire
 openssl rsautl -encrypt  -in ./tmp/parmAES -inkey ./key/publicKeyPE.pem -out $parmfile -pubin
 STATUS="$?"
 if [ ${STATUS} -ne 0 ];then
    echo $(date +"%d%m%Y-%T") "ERREUR - Erreur lors du chiffrement asymetrique openSSL rsault du fichier parametres AES"  1>>$logfile  
    exit 8
 else
    echo $(date +"%d%m%Y-%T") "INFO - Traitement chiffrement asymetrique RSA du fichier parametres AES"   1>>$logfile 
 fi
 
#--Chiffrement symetrique du fichier de données
 openssl enc  -$algoSymetric -z -base64 -in $filetoencrypt -out $encryptedfile  -K $AESkey -iv $AESiv
 STATUS="$?"
 if [ ${STATUS} -ne 0 ];then
    echo $(date +"%d%m%Y-%T") "ERREUR - Erreur lors du chiffrement symetrique openSSL enc du fichier de données"  1>>$logfile  
    exit 8
 else
    echo $(date +"%d%m%Y-%T") "INFO - Traitement chiffrement symetrique RSA du fichier à destination APEC"  1>>$logfile 
 fi
#-- tar des deux fichiers
# f1=$(basename ${parmfile})
# f2=$(basename ${encryptedfile})
# zip=$(basename ${TARfile})
 exec >> $logfile                                                                      
 exec 2>&1
 tar -cvf ${TARfile}  --directory ./out $(basename ${parmfile}) $(basename ${encryptedfile})
  
 STATUS="$?"
 if [ ${STATUS} -ne 0 ];then
    echo $(date +"%d%m%Y-%T") "ERREUR - TAR des fichiers"  $TARfile >>$logfile  
    exit 8
 else  
    echo $(date +"%d%m%Y-%T") "INFO - TAR des deux fichiers data + parametres AES" $Tarfile 1>>$logfile 
 fi
#### IMPORTANT A SUPPRIMER EN PROD
#--simuler le transfert
 cp ${TARfile} ../DECRYPT/in/$(basename ${TARfile})
#### IMPORTANT A  AJOUTER EN PROD
#rm -f  ./tmp/*
 
