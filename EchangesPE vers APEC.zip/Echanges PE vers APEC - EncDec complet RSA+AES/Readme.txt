INTRODUCTION
============


INSTALLATION
============
Apres avoir de-zipper le fichier , on obtient deux parties  sous Echanges PE vers APEC - EncDec complet RSA+AES:

�	ENCRYPT
Le shell ./encrypt/encrypt.sh chiffre le fichier FichierAller.csv qui est sous le r�pertoire .encrypt/in. Il faut la partie de la cl� publique sous ./encrypt/key. 
Le chiffrement produit un fichier tar echange-pe-apec-10122021.tgz contenant le fichier aes.parm(chiffr� RSA avec la cl� publique) et un fichier FichierAller.csv(chiffr� avec la cl� AES contenu dans le fichier pr�c�dent) dans le r�pertoire ./encrypt/out.
Le nom et la localisation des fichiers sont modifiables dans des variables en t�te du script.

�	DECRYPT
Le shell ./decrypt/decrypt.sh detare et dechiffre le fichier d�pos� sous ./decrypt/in . Le fichier data final est sous ./decrypt/out/FichierAller.csv 
Le r�pertoire ./decrypt/key doit contenir la cl� priv�e
Le nom et la localisation des fichiers sont modifiables dans des variables en t�te du script.


Pour les tests, voici un petit mode op�ratoire :

�	Copier la cl� priv� dans ./decrypt/key et la partie publique de cette cl� dans ./encrypt/key
�	Sous ./encrypt , lancer le shell ./encrypt.sh . Dans cette version de test le script copie le fichier tar obtenu dans le r�pertoire ./out/encrypt vers ./in/decrypt
�	J�ai  mis un petit fichier de test que tu peux remplacer dans /encrypt/in mais tu le remplacer par un de tes fichiers.
�	Sous ./decrypt, lancer le shell ./decrypt.sh. Dans cette version de test ce script fait un diff entre le fichier en entr�e du chiffrement (  ./in/encrypt/FichierAller.csv) et celui en sortie du chiffrement (./out/decrypt/FichierAller.csv)

