#!/bin/bash
parametersAESfiletodecrypt=./tmp/aes.parm
decryptedparametersAESfile=./tmp/aes.parm.dec
keypairfile=./key/KeypairPE.pem
datafiletodecrypt=./tmp/FichierAller.csv
decrypteddatafile=./out/FichierAller.csv
ZIPfile=./in/echange-pe-apec-10122021.tgz

logfile=./log/log$(date +"%d%m%Y-%T").txt
rm -f  ./out/*
rm -f  ./log/*
rm -f  ./tmp/*
#-- Controles
if [ ! -e $keypairfile ]; then
    echo $(date +"%d%m%Y-%T") "ERREUR - Cle de dechiffrement non trouvee" $keypairfile >>$logfile    
    exit 8 
fi
tar -xf $ZIPfile -C ./tmp   
#DEChiffrer le fichier paramétres AES
openssl rsautl -decrypt -in $parametersAESfiletodecrypt -inkey $keypairfile  -out $decryptedparametersAESfile

AESkey=$(grep -Po "(?<=^key=).*" $decryptedparametersAESfile)
AESiv=$(grep -Po "(?<=^iv =).*"  $decryptedparametersAESfile)
  

#Dechiffrer le fichier  AES

openssl enc -z -base64 -d  -aes-256-cbc -in $datafiletodecrypt -out $decrypteddatafile  -K $AESkey -iv $AESiv

#### IMPORTANT A ENLEVER EN PROD
filetocompare=../ENCRYPT/in/FichierAller.csv
diff $decrypteddatafile $filetocompare
#### IMPORTANT A  AJOUTER EN PROD
#rm -f  ./tmp/*
